# Example Of Count_in_list

- count_int_list(list, target)